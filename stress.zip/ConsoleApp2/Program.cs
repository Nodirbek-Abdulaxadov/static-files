﻿using LazyData;
using System.Collections.Concurrent;

record TestResult(int UserId, string Status, string Response);

class Program
{
    static async Task SubmitFormAsync(HttpClient client, string url, int userId, ConcurrentBag<TestResult> results)
    {
        using CancellationTokenSource cts = new();
        cts.CancelAfter(TimeSpan.FromSeconds(10)); // Set a timeout for the request

        try
        {
            HttpResponseMessage response = await client.GetAsync(url, cts.Token);
            string status = response.IsSuccessStatusCode ? "Success" : "Failed";
            results.Add(new TestResult(userId, status, $"{response.StatusCode} - {url}"));
        }
        catch (TaskCanceledException)
        {
            results.Add(new TestResult(userId, "Timeout", url));
        }
        catch (Exception ex)
        {
            results.Add(new TestResult(userId, "Error", $"{ex.Message} - {url}"));
        }
    }

    static async Task RunTask(int taskId, HttpClient client, List<string> urls, int userCount, ConcurrentBag<TestResult> results)
    {
        List<Task> tasks = new();

        for (int i = 1; i <= userCount; i++)
        {
            int userId = (taskId * userCount) + i;
            foreach (string url in urls)
            {
                tasks.Add(SubmitFormAsync(client, url, userId, results));
            }
        }

        await Task.WhenAll(tasks);
    }

    static async Task Main(string[] args)
    {
        const int threadCount = 100; // Number of concurrent tasks
        const int userCountPerTask = 1000; // Number of requests per task
        List<string> urls =
        [
            "http://172.17.5.4/addresspublicapi/coordinates?Radius=200&Latitude=41.31288691435732&Longitude=69.28158760070802",
            "http://172.17.5.4/addresspublicapi/name?addressName=%D0%90%D0%BD%D0%B4%D0%B8%D0%B6%D0%BE%D0%BD%20%D0%B2%D0%B8%D0%BB%D0%BE%D1%8F%D1%82%D0%B8,%20%D0%90%D0%BD%D0%B4%D0%B8%D0%B6%D0%BE%D0%BD%20%D1%88%D0%B0%D2%B3%D1%80%D0%B8,%20%D0%90%D2%B3%D0%BC%D0%B0%D0%B4%D0%B1%D0%B5%D0%BA%D2%B3%D0%BE%D0%B6%D0%B8-2%20%D1%82%D0%BE%D1%80%20%D0%BA%D1%9E%D1%87%D0%B0%D1%81%D0%B8,%207%D0%B0%20%D1%83%D0%B9",
            // Add more URLs as needed
        ];

        Console.WriteLine("Starting stress test...");

        ConcurrentBag<TestResult> results = new();
        using HttpClient client = new();
        List<Task> tasks = new();

        for (int i = 0; i < threadCount; i++)
        {
            tasks.Add(RunTask(i, client, urls, userCountPerTask, results));
        }

        await Task.WhenAll(tasks);

        Console.WriteLine("Stress test completed.");
        Console.WriteLine($"Total Results: {results.Count}");

        results.SaveAsExcelFile("results.xlsx");
    }
}
